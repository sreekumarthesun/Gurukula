/*
 ***************************************************************************************************************
'File Name			:	LoginPage 
'File Description	:	Contains all the Objects of "Login" Page.  
'Prerequisites		:	N/A
'Author				:	Sathya
'Reviewed By		:
'Date Created		:	04 August 2014
'Notes				:	
'****************************************************************************************************************
'****************************************************************************************************************
'                               C H A N G E                         H I S T O R Y
'****************************************************************************************************************
' Date    Change made by              Purpose of change
'-------- ------------------- --------------------------------------------------------------- -------------------
'
'****************************************************************************************************************
 */

package com.gurukulam.or;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class EntitiesPage {
		
	//Branch
	@FindBy(css = "[translate='global.menu.entities.branch']")
	public  WebElement welBranch;
	
	@FindBy(css = "[translate='gurukulaApp.branch.home.createLabel']")
	public WebElement btnCreateNewBranch; 
	
	@FindBy(css = "[translate='gurukulaApp.branch.home.createOrEditLabel']")
	public  WebElement welCreateOREditBranch;
	
	@FindBy(css = "[translate='entity.validation.minlength']")
	public WebElement welErrMinChar;

	@FindBy(css = "[translate='entity.validation.pattern']")
	public WebElement welErrPattern;
	
	@FindBy(name = "name")
	public  WebElement txtBranchName;
	
	@FindBy(name = "code")
	public  WebElement txtBranchCode;
	
	@FindBy(css = "[translate='entity.action.save']")
	public  WebElement btnSave;
	
	@FindBy(css = "[translate='entity.action.cancel']")
	public  WebElement btnCancel;
	
	@FindBy(css="table>tbody")
	public WebElement welTable;
	
	@FindBy(css="[type=submit]")
	public WebElement btnBack;
	
	@FindBy(xpath = "//h4[text()='Confirm delete operation']")
	public  WebElement welConfirmDelete;

	@FindBy(css = "[ng-disabled='deleteForm.$invalid']")
	public  WebElement btnDelete;
	
	@FindBy(id="searchQuery")
	public WebElement txtSearchQuery;
	
	@FindBy(css = ".glyphicon.glyphicon-search")
	public  WebElement btnSearch;
	
	//Staff
	@FindBy(css = "[translate='global.menu.entities.staff']")
	public  WebElement welStaff;
	
	@FindBy(css = "[translate='gurukulaApp.staff.home.createLabel']")
	public WebElement btnCreateNewStaff; 
	
	@FindBy(css = "[translate='gurukulaApp.staff.home.createLabel']")
	public WebElement welCreateOrEditStaff;
	
	@FindBy(name = "related_branch")
	public WebElement lstBranch;
	
}
