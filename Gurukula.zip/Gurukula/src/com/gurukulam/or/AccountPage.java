/*
 ***************************************************************************************************************
'File Name			:	LoginPage 
'File Description	:	Contains all the Objects of "Login" Page.  
'Prerequisites		:	N/A
'Author				:	Sathya
'Reviewed By		:
'Date Created		:	04 August 2014
'Notes				:	
'****************************************************************************************************************
'****************************************************************************************************************
'                               C H A N G E                         H I S T O R Y
'****************************************************************************************************************
' Date    Change made by              Purpose of change
'-------- ------------------- --------------------------------------------------------------- -------------------
'
'****************************************************************************************************************
 */

package com.gurukulam.or;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.gargoylesoftware.htmlunit.javascript.host.media.rtc.webkitRTCPeerConnection;

public class AccountPage {
	
	public By welDropDown = By.cssSelector(".dropdown-toggle");
	
	@FindBy(css="[href='#/settings']")
	public WebElement welsettings;
	
	@FindBy(css = "[translate='settings.title']")
	public WebElement titleOfPage;
	
	@FindBy(name = "firstName")
	public WebElement txtFirstname;

	@FindBy(name = "lastName")
	public WebElement txtLastname;

	@FindBy(name = "email")
	public WebElement txtEmail;

	@FindBy(name = "langKey")
	public WebElement lstLangKey;
	
	@FindBy(css = "[type='submit']")
	public WebElement btnSave;

	@FindBy(name = "password")
	public WebElement txtPassword;
	
	@FindBy(name="confirmPassword")
	public WebElement txtconfirmPassword;
	
	@FindBy(css = "[href='#/register']")
	public WebElement lnkRegister;

	@FindBy(css = "[translate='register.title']")
	public WebElement labelRegistration;
	
	@FindBy(css = "[translate='register.form.button']")
	public WebElement btnRegister;
	
}
