package com.gurukulam.test;

import java.beans.Visibility;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import com.gurukulam.impl.AccountPageImplementation;
import com.gurukulam.impl.EntitiesPageImplementation;
import com.gurukulam.impl.LoginPageImplementation;


public class Generic {
	public static WebDriver driver = null;
	public static ResourceBundle common=ResourceBundle.getBundle("common");;
	static LoginPageImplementation LoginPageImpl;
	static AccountPageImplementation AccountPageImpl;
	static EntitiesPageImplementation EntitiesPageImpl;	
	public Generic()	{

	}
	public static WebDriver setup(String browser,String hostname) throws MalformedURLException{
		try{
			if(browser.equalsIgnoreCase("ff")){
				driver=getWebDriver();
				return driver;
			}
			if(browser.equalsIgnoreCase("ie")){
				getIEWebDriver(common.getString("driverpath")+"IEDriverServer.exe");
				return driver;
			}
			if(browser.equalsIgnoreCase("cr")){
				getChromeWebdriver(common.getString("driverpath")+"chromedriver.exe");
				return driver;
			}

		}catch (Exception e) {
			e.printStackTrace();
			Reporter.log("Driver is not execited");
		} finally {

			browser = null;
			hostname = null;			
		}
		driver.manage().window().maximize();
		return driver;	
	}
	
	public static WebDriver getWebDriver() throws MalformedURLException
	{
		
			//Launching custom firefox			
			FirefoxProfile profile = new FirefoxProfile();
			profile.setAcceptUntrustedCertificates(true);
			profile.setAssumeUntrustedCertificateIssuer(true);
			driver = new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"),DesiredCapabilities.firefox());
			
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		return driver;
	}
	
	public static WebDriver getIEWebDriver(String IEDriverpath){
		
			System.setProperty("webdriver.ie.driver", IEDriverpath);
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS,true);
			capabilities.setVersion("8");
			driver=new InternetExplorerDriver(capabilities);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
		
		return driver;
	}
	
public static WebDriver getChromeWebdriver(String ChromeDriverpath){
		
			System.setProperty("webdriver.chrome.driver", ChromeDriverpath);
			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			capabilities.setCapability("chrome.switches", Arrays.asList("--ignore-certificate-errors"));
			driver = new ChromeDriver(capabilities);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		
		return driver;
	}
public static WebDriver getPhantomJSdriver(String phantomjsDriverpath){
		
			DesiredCapabilities  dCaps = new DesiredCapabilities();
			dCaps.setJavascriptEnabled(true);
			dCaps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,phantomjsDriverpath);
			dCaps.setCapability(PhantomJSDriverService.PHANTOMJS_CLI_ARGS, new String[] {"--web-security=no", "--ignore-ssl-errors=yes"});
			driver = new PhantomJSDriver(dCaps);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		
		return driver;
	}
	

	public static void quitWebDriver(){
		if(driver != null){
			driver.quit();
			driver = null;
		}
	}
	
	public static WebDriver glogin(String browser,String sysname,String Url, String username,String password) throws Exception{
		try{
			driver=Generic.setup(browser,sysname);			
			LoginPageImpl = PageFactory.initElements(driver, LoginPageImplementation.class);
			 AccountPageImpl = PageFactory.initElements(driver, AccountPageImplementation.class);
			 EntitiesPageImpl = PageFactory.initElements(driver, EntitiesPageImplementation.class);
			driver.get(Url);
			LoginPageImpl.lnkLogin.click();
			//Enter username
			LoginPageImpl.txtUsername.sendKeys(username);	
			//Enter Password
			LoginPageImpl.txtPwd.sendKeys(password);;		
			//Click on Login Button
			LoginPageImpl.btnAuthenticate.click();;
			Thread.sleep(3000);
			if(LoginPageImpl.welWelcomeMsg.getText().contains("You are logged in as user \"+username+\"")){
				throw new Exception();
			}
			return driver;
		}catch(Exception e){
				throw new Exception();
			}
		
	}
	
	public boolean gcreateBranch(String branchname,String code) throws Exception {
		try{
			
			String branches[]=branchname.split(",");
			String codes[]=code.split(",");
			for(int i=0;i<branches.length;i++){
				gClickLinkOrButtonElement(EntitiesPageImpl.btnCreateNewBranch);				
				gIsDisplayed(EntitiesPageImpl.welCreateOREditBranch);
				new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchName).perform();
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,branches[i]);
				new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchCode).perform();
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchCode,codes[i]);
				gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);				
			}
			return true;
			
		}catch(Exception e){
			throw new Exception();
		}
		
		
	}
	
	public void glogout() throws Exception{
		driver.findElements(AccountPageImpl.welDropDown).get(1).click();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.querySelector(\"a[ng-click='logout()']\").click()");
		driver.close();
		quitWebDriver();
	}
	
	public boolean gClickLinkOrButton(By strLink,int index) throws Exception{
		try{
			List<WebElement> lstLinks = driver.findElements(strLink);
			lstLinks.get(index).click();			
			Thread.sleep(3000);
			return true;	


		}
		catch(Exception e){
			throw new Exception();
		}
	}


		public boolean gClickLinkOrButtonElement(WebElement welBranch) throws Exception{
			try{
				welBranch.click();			
				Thread.sleep(2000);
				return true;	


			}
			catch(Exception e){
				throw new Exception();
			}


	}
	public static void gIsDisplayed(WebElement welCreateOREditBranch){
		try{
			welCreateOREditBranch.isDisplayed();
		}catch (Exception e){                  
			throw new NoSuchElementException();
		}	

	}
	public String gReportDetails(String computerName, String methodName,String browser, String stepNo) throws IOException{
		String returnVal=null;
		String DateVal = gDateFunction();				
		//Folder to save the screen shots 
		String path = common.getString("screenshot"); 
		String fileName = computerName+"_"+methodName+"_"+browser+"_"+stepNo+"_"+DateVal+".jpg";



		WebDriver augmentedDriver = new Augmenter().augment(driver);
		File screenshot = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE); 
		FileUtils.copyFile(screenshot, new File(path+fileName));


		returnVal = stepNo +" : Location of the Screen shot - "+"\\servername\\Screenshots\\"+computerName+"_"+methodName+"_"+stepNo+"_"+DateVal+".jpg";
		
		return returnVal;

	}
	
	public String gDateFunction(){
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String dateVal = dateFormat.format(date);
		dateVal = dateVal.replaceAll(" ", "_");
		dateVal = dateVal.replaceAll("/", "_");
		dateVal = dateVal.replaceAll(":", "_");
		return dateVal;

	}


	public enum conditionalWait 
	{ 
		VISIBILITY, INVISIBILITY, FRAME , PRESENCE ,POPUPALERT; 
	}
	public void gExplicitWait(WebElement welCreateOREditBranch,int maxTimeOut , String strConditionMode , String strName) throws InterruptedException{

		conditionalWait mode = conditionalWait.valueOf(strConditionMode.toUpperCase());		 

		switch (mode) {
		case VISIBILITY:
			(new WebDriverWait(driver, maxTimeOut))
			.until(ExpectedConditions.visibilityOfElementLocated((By) welCreateOREditBranch));			
			break;

		case INVISIBILITY:
			(new WebDriverWait(driver, maxTimeOut))
			.until(ExpectedConditions.invisibilityOfElementLocated((By) welCreateOREditBranch));
			break;

		case FRAME:
			(new WebDriverWait(driver, maxTimeOut))
			.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(strName));
			new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Thomson Reuters/')]")));
			break;	

		case PRESENCE:
			(new WebDriverWait(driver, maxTimeOut))
			.until(ExpectedConditions.presenceOfElementLocated((By) welCreateOREditBranch));
			break;	

		case POPUPALERT:	
			List<WebElement> popupElements = driver.findElements((By) welCreateOREditBranch);
			int count=popupElements.size();
			if(count>0)
			{
				(new WebDriverWait(driver, maxTimeOut))
				.until(ExpectedConditions.visibilityOfElementLocated((By) welCreateOREditBranch));
				for(int j =0 ; j<count ; j++)
				{
					popupElements.get(j).click();
					Thread.sleep(1500);
				}
				break;
			}


		}

	}

	
	//'***********************************************************************************************************************
		//'Function Name          :     gEditTextbox
		//'Script Description     :     To perform enter text in a textbox based on name property
		//'Input Parameters :     
		//'   1.    strName  - Name of the Textbox
		//	  2. 	strValue - Value of the Textbox
		//'Return Value           :      true
		//'Author                 :     Sreekumar      
		//'Reviewed By            :
		//'Date Created           :     21st June,2016
		//
		//'***********************************************************************************************************************
		//'***********************************************************************************************************************
		//'         C H A N G E                         H I S T O R Y

		public boolean gEditTextbox(By txtKeywords,String strValue,int index) throws Exception{
			try{							
				List<WebElement> ls=driver.findElements(txtKeywords);	
				ls.get(index).clear();
				ls.get(index).sendKeys(strValue);
				return true; 	    	  

			}
			catch(Exception e){
				throw new Exception();
			}


		}
		
		public boolean gEditTextboxWebElement(WebElement txtKeywords,String strValue) throws Exception{
			try{							
				txtKeywords.clear();
				txtKeywords.sendKeys(strValue);
				return true; 	    	  

			}
			catch(Exception e){
				throw new Exception();
			}


		}

		

		public void gsearchBranchOrStaff(String branch) throws Exception {
			try{					
				gEditTextboxWebElement(EntitiesPageImpl.txtSearchQuery, branch);
				gClickLinkOrButtonElement(EntitiesPageImpl.btnSearch);
				gvaidateSearchQuery(branch);			
			}catch(Exception e){
				throw new Exception();
			}
			
		}

				
		public boolean gvalidateDelete(String id) throws Exception {
			try{
				if(EntitiesPageImpl.welTable.getText().equalsIgnoreCase("")){				
					return true;
				}
				
				List<WebElement> rows=EntitiesPageImpl.welTable.findElements(By.tagName("tr"));
				for(int i=0;i<rows.size();i++){
						if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(1)")).getText().equalsIgnoreCase(id)){						
							throw new Exception();				
						}
						
				}
				return true;
			
			}catch(Exception e){
				throw new Exception();
			}
			
			
		}



		public void gvaidateSearchQuery(String branch) throws Exception {
			boolean flag=false;
			List<WebElement> rows=EntitiesPageImpl.welTable.findElements(By.tagName("tr"));
			for(int i=0;i<rows.size();i++){
				List<WebElement> cols=rows.get(i).findElements(By.tagName("td"));
				for(int j=0;j<cols.size();j++){
					if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child("+(j+1)+")")).getText().equalsIgnoreCase(branch)){
						flag=true;
					}
					
					
				}
				if(!flag){
					throw new Exception();
				}
				
			}
			
			
		}
		

				
		
		//       '**************************************************************************************************************
		//     'Function Name             :      gRadioSelectValue
		//     'Script Description        :      To set the value of a Radio Button
		//     'Input Parameters          :      1. strRadioValue                                                    2. strRadioValue - Value to be selected in the Radiobutton(Ex: 0,1, etc...)
		//     'Return Value              :      true
		//     'Author                    :      Sreekumar 
		//     'Reviewed By               :
		//     'Test Case ID              :      Generic Function
		//     'Date Created           	:  24th June, 2016
		//
		//       '****************************************************************************************************************
		//       '****************************************************************************************************************
		//     '                               C H A N G E                         H I S T O R Y
		//       '****************************************************************************************************************
		//     ' Date    Change made by              Purpose of change
		//     '-------- ------------------- --------------------------------------------------------------- ------------------------------------------------
		//       '******************************************************************************************************************
		public boolean gRadioSelectValue(By strName, String strRadioValue){
			try{
				// List<WebElement> strRadioList = driver.findElements(By.name(strName));
				List<WebElement> strRadioList = driver.findElements(strName); 
				for (WebElement indRadio : strRadioList) {
					if (strRadioValue.equalsIgnoreCase(indRadio.getAttribute("value"))){
						indRadio.click();
						break;
					}
				}
				return true;
			}catch (Exception e){                    
				throw new NoSuchElementException();
			}
		}





		//       '**************************************************************************************************************
		//     'Function Name                    :      gListGetValue
		//     'Script Description        :      To Get the value in a List box
		//     'Input Parameters          :      strId - Id property of the List Box 
		//     'Return Value              :      strText - Value(Text) of the list box which is selected
		//     'Author                                  :      Raishankar J  
		//     'Reviewed By               :
		//     'Test Case ID              :  Generic Function  
		//     'Date Created           :  2nd July, 2016
		//
		//       '****************************************************************************************************************
		//       '****************************************************************************************************************
		//     '                               C H A N G E                         H I S T O R Y
		//       '****************************************************************************************************************
		//     ' Date    Change made by              Purpose of change
		//     '-------- ------------------- --------------------------------------------------------------- ------------------------------------------------
		//       '******************************************************************************************************************

		public String gListGetValue(WebElement lstBranch){
			try{
				String strText=null;
				Select selectListBox = new Select(driver.findElement((By) lstBranch));
				strText = selectListBox.getFirstSelectedOption().getText();

				return strText;
			}catch (Exception e){                    
				throw new NoSuchElementException();
			}
		}
		
		public boolean gListSelect(WebElement lstBranch, String newStaffnames){
			try{
				new Select(lstBranch).selectByVisibleText(newStaffnames);
				Thread.sleep(3000);
				return true;

			}catch (Exception e){
				throw new NoSuchElementException();
			}

		}

		public boolean gvalidateEdit(String[] newdata1,String newStaffnames[]) throws Exception {
			try{
				
				int count=0;
				for(int i=0;i<newdata1.length;i++){
						if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(3)")).getText().equalsIgnoreCase(newdata1[count])){
							if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(2)")).getText().equalsIgnoreCase(newStaffnames[count])){
								count++;
							}
							
						}
						
				}
				if(count==0){
					throw new Exception();
				}
			}catch(Exception e){
				throw new Exception();
			}
			return true;
			
		}



		//       '**************************************************************************************************************
		//     'Function Name                    :      gRadioGetValue
		//     'Script Description        :      To Get the value of a Radio Button
		//     'Input Parameters          :      strName - Name property of the Radiobutton
		//     'Return Value              :      strText - Value of the Radiobutton(Ex: 0,1, etc..)
		//     'Author                                  :      Raishankar J  
		//     'Reviewed By               :
		//     'Test Case ID              :      Generic Function     
		//     'Date Created           :  14th June, 2016
		//
		//       '****************************************************************************************************************
		//       '****************************************************************************************************************
		//     '                               C H A N G E                         H I S T O R Y
		//       '****************************************************************************************************************
		//     ' Date    Change made by              Purpose of change
		//     '-------- ------------------- --------------------------------------------------------------- ------------------------------------------------
		//       '******************************************************************************************************************

		public String gRadioGetValue(By strName){
			try{
				String strText=null;

				//    List<WebElement> radiostrDocHeader = driver.findElements(By.name(strName));
				List<WebElement> radiostrDocHeader = driver.findElements(strName);
				for (WebElement indRadioradiostrDocHeader : radiostrDocHeader) {
					if (indRadioradiostrDocHeader.isSelected()==true){
						strText = indRadioradiostrDocHeader.getAttribute("value");
						//System.out.println(strText);
						break;
					}                    
				}

				return strText;

			}catch (Exception e){                    
				throw new NoSuchElementException();
			}
		}

		//       '**************************************************************************************************************
		//     'Function Name             :      gCheckBoxSelect
		//     'Script Description        :      To Set a value in a CheckBox (On/OFF)
		//     'Input Parameters          :      1. strId  -  ID property of the list box to be selected
		//                                                     2. strChkBoxValue - Value to be selected (ON/OFF)
		//     'Return Value              :      boolean(true/false)
		//     'Author                                  :      Raishankar J  
		//     'Reviewed By               :
		//     'Test Case ID              :      Generic Function     
		//     'Date Created           :  14th June, 2016
		//
		//       '****************************************************************************************************************
		//       '****************************************************************************************************************
		//     '                               C H A N G E                         H I S T O R Y
		//       '****************************************************************************************************************
		//     ' Date    Change made by              Purpose of change
		//     '-------- ------------------- --------------------------------------------------------------- ------------------------------------------------
		//       '******************************************************************************************************************

		public boolean gCheckBoxSelect(By strId, String strChkBoxValue){
			try{

				boolean strFlag = driver.findElement(strId).isSelected();                  
				if ((strFlag == false && strChkBoxValue == "ON")|| (strFlag == true && strChkBoxValue == "OFF")){
					driver.findElement(strId).click();       
					Thread.sleep(1000);
				}                    
				return true;

			}catch (Exception e){                    
				throw new NoSuchElementException();
			}
		}



	
	public static void setDefaultTimeOut(WebDriver webDriver,long defaultTimeOutInSeconds){
		webDriver.manage().timeouts().implicitlyWait(defaultTimeOutInSeconds, TimeUnit.SECONDS);
	}

	public static void setPageLoadTimeOut(WebDriver webDriver,long defaultTimeOutInSeconds){
		webDriver.manage().timeouts().pageLoadTimeout(defaultTimeOutInSeconds, TimeUnit.SECONDS);
	}

	public static void setTextField(WebDriver webDriver, String elementId,String valueToSet){
		WebElement webElement = webDriver.findElement(By.id(elementId));
		webElement.clear();
		webElement.sendKeys(valueToSet);

	}
	
	public static void SelectOption(WebDriver webDriver,String ListName,String Option) {
		new Select(driver.findElement(By.id(ListName))).selectByVisibleText(Option);
		
	}
	public static boolean isElementPresent(WebDriver webDriver,By selector) {
		return webDriver.findElements(selector).size()>0;
	}

	public static boolean isExpectedPage(WebDriver webDriver,String pageTitle){
		String actualTitle = webDriver.findElement(By.tagName("title")).getText();
		return actualTitle.equals(pageTitle);
	}

	

	public static boolean isAlertPresent(WebDriver webDriver) {
		try {
			webDriver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public static String closeAlertAndGetItsText(WebDriver webDriver,boolean acceptNextAlert) {
		try {
			Alert alert = webDriver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}


