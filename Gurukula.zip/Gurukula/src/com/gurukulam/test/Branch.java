package com.gurukulam.test;


import java.util.List;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Branch extends Generic {
	public static ResourceBundle common=ResourceBundle.getBundle("common");;
	public static ResourceBundle branch=ResourceBundle.getBundle("branch");;
	public static ResourceBundle staff=ResourceBundle.getBundle("staff");;
	private static WebDriver driver=null;
		
	
	//Crate a branch	
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH01(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH01";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	

				gDeleteAll();
				
				stepInfo = "Step 3 : failed to create branch - gcreateBranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH01",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();				
			}
	}

	//view branch
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH02(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH02";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				
				gDeleteAll();
				
				stepInfo = "Step 3 : failed to view branch - fviewBranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				
				fviewBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"),"view");
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH02",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();				
			}
	}
	
	//search branch
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH03(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH03";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";		
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				
				stepInfo = "Step 3 : failed to search branch - fsearchBranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				//gsearchBranchOrStaff(branch.getString(testString+".branchid"));
				gsearchBranchOrStaff(branch.getString(testString+".branchname"));
				gsearchBranchOrStaff(branch.getString(testString+".branchcode"));
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH03",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
				gDeleteAll();
				glogout();				
			}
	}

	//Edit Branch
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH04(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH04";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);				
				
				stepInfo = "Step 3 : failed to edit branch - feditBranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				
				feditBranch(branch.getString(testString+".branchname"),branch.getString(testString+".newbranchname"),branch.getString(testString+".newbranchcode"));
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH04",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();			
			}
	}


	//Delete Branch
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH05(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH05";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				
				stepInfo = "Step 3 : failed to delete branch - fdeleteBranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				
				stepInfo = "Step 4 : failed to delete branch - fdeleteBranch ";
				fdeleteBranch(branch.getString(testString+".branchname"));
			
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH05",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();
				
			}
	}

	//view branch using ID
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH06(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH06";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				
				stepInfo = "Step 3 : failed to view id - fviewbranch ";
				gcreateBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"));
				
				fviewBranch(branch.getString(testString+".branchname"),branch.getString(testString+".branchcode"),"id");
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH06",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();			
			}
	}
	
	//validation on branch	
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void BRANCH07(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="BRANCH07";				
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				
				stepInfo = "Step 3 : failed to create branch - gcreateBranch ";
				gcreateBranch(branch.getString(testString+".branchname.valid"),branch.getString(testString+".branchcode"));
								
				driver.findElement(By.cssSelector("table>tbody>tr:nth-child(1)>td:nth-child(4)>button:nth-child(2)")).click();
				Thread.sleep(5000);
				
				stepInfo = "Step 4 : failed to display text - gEditTextboxWebElement ";
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,branch.getString(testString+".branchname.min5char"));				
				gIsDisplayed(EntitiesPageImpl.welErrMinChar);
				
				stepInfo = "Step 5 : failed to display text - gEditTextboxWebElement ";
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,branch.getString(testString+".branchname.numbers"));
				gIsDisplayed(EntitiesPageImpl.welErrPattern);
				
				stepInfo = "Step 6 : failed to display text - gEditTextboxWebElement ";
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,branch.getString(testString+".branchname.specialcharacters"));
				gIsDisplayed(EntitiesPageImpl.welErrPattern);
				
				stepInfo = "Step 7 : failed to display text - gEditTextboxWebElement ";
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,branch.getString(testString+".branchname.valid"));
				gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);
								
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"BRANCH07",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;
				gDeleteAll();
				glogout();				
			}
	}

	
	
	
	private boolean fviewBranch(String branchname,String code,String modify) throws Exception {
		try{					
			String[] codes=code.split(",");
			String[] branchnames=branchname.split(",");
			fSearchElementInTable(EntitiesPageImpl.welTable,branchnames,codes, modify);
				
			return true;
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
	private boolean feditBranch(String branchname,String newbranchname,String newbranchcode) throws Exception {
		try{		
			String newbranchid=null;		
			String[] branchnames=branchname.split(",");
			String[] newbranchnames=newbranchname.split(",");			
			String[] newbranchcodes=newbranchcode.split(",");
			for(int i=0;i<branchnames.length;i++){
				if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(2)")).getText().equalsIgnoreCase(branchnames[i])){
					String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(1)")).getText();
					if(i==0 || i>1){
						newbranchid=branchid;
					}
										
					if(i==1 && branchid.equalsIgnoreCase(newbranchid)){
						continue;
					}
					driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(4)>button:nth-child(2)")).click();
					Thread.sleep(5000);
					new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchName).perform();
					gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,newbranchnames[i]);
					new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchCode).perform();
					gEditTextboxWebElement(EntitiesPageImpl.txtBranchCode,newbranchcodes[i]);		
					gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);
					gvalidateEdit(newbranchnames,newbranchcodes,"branch");
				}
			}
			return true;
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}

	public void fSearchElementInTable(WebElement table,String[] branchnames,String[] codes, String modify) throws Exception{
		try{
			
			String newbranchid=null;
			
			for(int i=0;i<branchnames.length;i++){
				if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(2)")).getText().equalsIgnoreCase(branchnames[i])){
					String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(1)")).getText();
					if(i==0 || i>1){
						newbranchid=branchid;
					}
										
					if(i==1 && branchid.equalsIgnoreCase(newbranchid)){
						continue;
					}
					if(modify.equalsIgnoreCase("view")){
						driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(4)>button:nth-child(1)")).click();
						Thread.sleep(5000);
					}else{
						
						driver.findElement(By.cssSelector("[href='#/branch/"+Integer.parseInt(branchid)+"']")).click();
						Thread.sleep(5000);
					}
					
					Assert.assertEquals(driver.findElements(By.tagName("input")).get(0).getAttribute("value"),branchnames[i]);	
					Assert.assertEquals(driver.findElements(By.tagName("input")).get(1).getAttribute("value"),codes[i]);
					EntitiesPageImpl.btnBack.click();					
				}
							
				
			}
		
				}
		catch(Exception e){
			throw new Exception();
		}


	}

	
	private void fdeleteBranch(String branchname) throws Exception {
		try{					
			String[] branchnames=branchname.split(",");
			for(int i=0;i<branchnames.length;i++){				
				EntitiesPageImpl.welConfirmDelete.isDisplayed();
				List<WebElement> rows=EntitiesPageImpl.welTable.findElements(By.tagName("tr"));
				boolean flag=false;
				for(int j=0;j<rows.size();j++){					
					if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(2)")).getText().equalsIgnoreCase(branchnames[i])){
						String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(1)")).getText();
						driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(4)>button:nth-child(3)")).click();
						Thread.sleep(5000);
						driver.findElement(By.xpath("//p[text()='Are you sure you want to delete Branch "+branchid+"?']")).isDisplayed();
						EntitiesPageImpl.btnDelete.click();
						gvalidateDelete(branchid);		
						flag=true;
						break;
					}			
					
					
				}
				if(flag==false){
					throw new Exception();
				}
				}
									
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
	

				
}
