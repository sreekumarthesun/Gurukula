package com.gurukulam.test;


import java.util.List;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Account extends Generic {
	public static ResourceBundle common=ResourceBundle.getBundle("common");;
	public static ResourceBundle branch=ResourceBundle.getBundle("branch");;
	public static ResourceBundle staff=ResourceBundle.getBundle("staff");;
	private static WebDriver driver=null;
	
	
	//update settings	
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void ACCOUNT01(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="ACCOUNT01";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,1);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(AccountPageImpl.welsettings);	
				stepInfo = "Step 3 : failed to update settings ";
				if(!AccountPageImpl.titleOfPage.getText().contains(username)){
					throw new Exception();
				}
				gEditTextboxWebElement(AccountPageImpl.txtFirstname, "firstname");
				gEditTextboxWebElement(AccountPageImpl.txtLastname, "lastname");
				gEditTextboxWebElement(AccountPageImpl.txtEmail, "email");
				gListSelect(AccountPageImpl.lstLangKey, "ENGLISH");
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":");				
				gReportDetails(sysname,"ACCOUNT01",browser,stepNo[0]);
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}

	//update password
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void ACCOUNT02(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="ACCOUNT02";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,1);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("document.querySelector(\"span[translate='global.menu.account.password']\").click()");
				gEditTextboxWebElement(AccountPageImpl.txtPassword, password);
				gEditTextboxWebElement(AccountPageImpl.txtconfirmPassword, "newpassword");
				gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);
				
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"ACCOUNT02",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}
	
	//verify active sessions
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void ACCOUNT03(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="ACCOUNT03";
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";
				driver=glogin(browser,sysname,url,username,password);
				gClickLinkOrButton(AccountPageImpl.welDropDown,1);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(AccountPageImpl.welsettings);	
				stepInfo = "Step 3 : failed to update settings ";								
				if(!AccountPageImpl.titleOfPage.getText().contains("username")){
					throw new Exception();
				}
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"ACCOUNT03",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}

	//Register new account
	@Parameters({ "browser", "sysname", "url", "username", "password" })
	@Test
	public void ACCOUNT04(String browser, String sysname, String url,String username, String password) throws Exception{
		String stepInfo = null;
			try{
				String testString="ACCOUNT04";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButtonElement ";				
				gClickLinkOrButtonElement(AccountPageImpl.lnkRegister);
				stepInfo = "Step 2 : failed to click button - gIsDisplayed ";
				gIsDisplayed(AccountPageImpl.labelRegistration);	
				stepInfo = "Step 3 : failed to update settings ";
				gEditTextboxWebElement(AccountPageImpl.txtEmail, "email");
				gEditTextboxWebElement(AccountPageImpl.txtPassword, password);
				gEditTextboxWebElement(AccountPageImpl.txtconfirmPassword, "newpassword");
				gClickLinkOrButtonElement(AccountPageImpl.btnRegister);
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"ACCOUNT04",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}
			
}
