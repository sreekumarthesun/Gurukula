package com.gurukulam.test;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;












































import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Staff extends Generic {
	public static ResourceBundle common=ResourceBundle.getBundle("common");;
	public static ResourceBundle branch=ResourceBundle.getBundle("branch");;
	public static ResourceBundle staff=ResourceBundle.getBundle("staff");;
	private static WebDriver driver=null;
	
	
	//Crate a staff
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF01(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF01";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";				
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welBranch);	
				stepInfo = "Step 3 : failed to create branch - fcreateBranch ";
				gcreateBranch(staff.getString(testString+".branchname"),staff.getString(testString+".branchcode"));
				
				stepInfo = "Step 4 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 5 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);				
				stepInfo = "Step 6 : failed to create staff - fcreateStaff";
				fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
				stepInfo = "Step 7 : failed to delete staff - fcreateStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF01",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
				glogout();				
			}
	}

	//view staff
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF02(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF02";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);		
				
				stepInfo = "Step 3 : failed to create staff - fcreateStaff";
				fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
				
				stepInfo = "Step 4 : failed to view staff - fviewStaff";
				fviewStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"),"view");
				
				stepInfo = "Step 5 : failed to delete staff - fdeleteStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
				
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF02",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}
	
	//search staff
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF03(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF03";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);		
				
				stepInfo = "Step 3 : failed to create staff - fcreateStaff";
				fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
				
				stepInfo = "Step 4 : failed to search staff - gsearchStaff";				
				gsearchBranchOrStaff(staff.getString(testString+".staffname"));
						
				stepInfo = "Step 5 : failed to delete staff - fdeleteStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF03",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}

	//Edit Staff
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF04(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF04";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);		
				
				stepInfo = "Step 3 : failed to create staff - fcreateStaff";
				fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
		
				stepInfo = "Step 4 : failed to edit staff - feditStaff";
				feditStaff(staff.getString(testString+".branchname"),staff.getString(testString+".newstaffname"),staff.getString(testString+".newbranchname"));
				
				stepInfo = "Step 5 : failed to delete staff - fdeleteStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF04",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}


	//Delete Branch
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF05(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF05";
				driver=glogin(browser,sysname,url,username,password);
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);
				
				stepInfo = "Step 3 : failed to create staff - fcreateStaff";
				fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
		
				stepInfo = "Step 4 : failed to delete staff - fdeleteStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF05",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}

	//view staff id
	@Parameters({ "browser", "sysname", "url", "username", "password","feature" })
	@Test
	public void STAFF06(String browser,String sysname,String url,String username,String password,String feature) throws Exception{
		String stepInfo = null;
			try{
				String testString="STAFF06";
				driver=glogin(browser,sysname,url,username,password);
				
				stepInfo = "Step 1 : failed to click  - gClickLinkOrButton ";								
				gClickLinkOrButton(AccountPageImpl.welDropDown,0);
				stepInfo = "Step 2 : failed to click button - gClickLinkOrButtonElement ";
				gClickLinkOrButtonElement(EntitiesPageImpl.welStaff);		
				
				stepInfo = "Step 3 : failed to create staff - fcreateStaff";
				//fcreateStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"));
				
				stepInfo = "Step 4 : failed to view staff - fviewStaff";
				fviewStaff(staff.getString(testString+".staffname"),staff.getString(testString+".branchname"),"id");
				
				stepInfo = "Step 5 : failed to delete staff - fdeleteStaff";
				fdeleteStaff(staff.getString(testString+".branchname"));
									
				
			}catch(NoSuchElementException e){				
				String stepNo[] = stepInfo.split(":"); 
				gReportDetails(sysname,"STAFF06",browser,stepNo[0]);					
				throw new NoSuchElementException(stepInfo);
			}finally{
				stepInfo = null;				
								
			}
	}
	
	private void fcreateStaff(String staffname,String branchname) throws Exception {
		try{
			
			String branchnames[]=branchname.split(",");
			String staffnames[]=staffname.split(",");
			for(int i=0;i<branchnames.length;i++){
				gClickLinkOrButtonElement(EntitiesPageImpl.btnCreateNewStaff);				
				gIsDisplayed(EntitiesPageImpl.welCreateOrEditStaff);
				new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchName).perform();
				gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,staffnames[i]);
				gListSelect(EntitiesPageImpl.lstBranch,branchnames[i]);
				gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);
			}
			
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
	private void fviewStaff(String staffname,String branchname,String modify) throws Exception {
		try{					
			
			String[] branchnames=branchname.split(",");
			String[] staffnames=staffname.split(",");
			fSearchElementInTable(EntitiesPageImpl.welTable,branchnames,staffnames,modify);
						
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
	private boolean feditStaff(String branchname,String newStaffname,String newbranchname) throws Exception {
		try{		
			String newbranchid=null;		
			String[] branchnames=branchname.split(",");
			String[] newbranchnames=newbranchname.split(",");		
			String[] newStaffnames=newStaffname.split(",");
			for(int i=0;i<branchnames.length;i++){
				if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(3)")).getText().equalsIgnoreCase(branchnames[i])){
					String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(1)")).getText();
					if(i==0 || i>1){
						newbranchid=branchid;
					}
										
					if(i==1 && branchid.equalsIgnoreCase(newbranchid)){
						continue;
					}
					driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(4)>button:nth-child(2)")).click();
					Thread.sleep(5000);
					new Actions(driver).moveToElement(EntitiesPageImpl.txtBranchName).perform();
					gEditTextboxWebElement(EntitiesPageImpl.txtBranchName,newStaffnames[i]);
					gListSelect(EntitiesPageImpl.lstBranch, newbranchnames[i]);
					gClickLinkOrButtonElement(EntitiesPageImpl.btnSave);
					gvalidateEdit(newbranchnames,newStaffnames);
				}
			}
			return true;
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}


	
	public void fSearchElementInTable(WebElement table,String[] branchnames,String[] staffnames, String modify) throws Exception{
		try{
			
			String newbranchid=null;
			
			for(int i=0;i<branchnames.length;i++){
				if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(3)")).getText().equalsIgnoreCase(branchnames[i])){
					String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(1)")).getText();
					if(i==0 || i>1){
						newbranchid=branchid;
					}
										
					if(i==1 && branchid.equalsIgnoreCase(newbranchid)){
						continue;
					}
					if(modify.equalsIgnoreCase("view")){
						driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(i+1)+")>td:nth-child(4)>button:nth-child(1)")).click();
						Thread.sleep(5000);
					}else{
						
						driver.findElement(By.cssSelector("[href='#/staff/"+Integer.parseInt(branchid)+"']")).click();
						Thread.sleep(5000);
					}
					
					Assert.assertEquals(driver.findElements(By.tagName("input")).get(0).getAttribute("value"),staffnames[i]);	
					Assert.assertEquals(driver.findElements(By.tagName("input")).get(1).getAttribute("value"),branchnames[i]);			
					EntitiesPageImpl.btnBack.click();					
				}
							
				
			}
		
				}
		catch(Exception e){
			throw new Exception();
		}


	}
	

	
	
	private void fdeleteStaff(String branchname) throws Exception {
		try{					
			String[] branchnames=branchname.split(",");
			for(int i=0;i<branchnames.length;i++){				
				EntitiesPageImpl.welConfirmDelete.isDisplayed();
				List<WebElement> rows=EntitiesPageImpl.welTable.findElements(By.tagName("tr"));
				boolean flag=false;
				for(int j=0;j<rows.size();j++){					
					if(driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(3)")).getText().equalsIgnoreCase(branchnames[i])){
						String branchid=driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(1)")).getText();
						driver.findElement(By.cssSelector("table>tbody>tr:nth-child("+(j+1)+")>td:nth-child(4)>button:nth-child(3)")).click();
						Thread.sleep(5000);
						driver.findElement(By.xpath("//p[text()='Are you sure you want to delete Staff "+branchid+"?']")).isDisplayed();
						EntitiesPageImpl.btnDelete.click();
						gvalidateDelete(branchid);		
						flag=true;
						break;
					}			
					
					
				}
				if(flag==false){
					throw new Exception();
				}
				}
									
			
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
	
	
	/*private void fdeleteStaff(String staffid) throws Exception {
		try{					
			String[] staffids=staffid.split(",");
			for(int i=0;i<staffids.length;i++){
				//gSearchElementInTable(EntitiesPageImpl.welTable,staffids[i],"delete");
				EntitiesPageImpl.welConfirmDelete.isDisplayed();
				driver.findElement(By.xpath("//p[text()='Are you sure you want to delete Staff "+staffids[i]+"?']")).isDisplayed();
				EntitiesPageImpl.btnDelete.click();
				gvalidateDelete(staffids[i]);
				}
					
		}catch(Exception e){
			throw new Exception();
		}
		
	}
	
*/	

}	